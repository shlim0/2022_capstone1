package catharsis.space_server.entity_repository;

import catharsis.space_server.entity.ImagePath;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ImagePathRepository extends JpaRepository<ImagePath, Integer> {
    Optional<ImagePath> findByImagePath(String imagePath);

    Optional<ImagePath> findById(Integer id);
}
