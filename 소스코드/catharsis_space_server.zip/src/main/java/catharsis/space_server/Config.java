package catharsis.space_server;

public class Config {
    public final static String IMAGE_SERVER = "127.0.0.1:12345"; // 이미지 서버 주소 및 포트
}
