package catharsis.space_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpaceServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
