package catharsis.space_server;

import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.io.*;
import java.net.URI;

import static catharsis.space_server.Config.IMAGE_SERVER;

public class ImageManager {
    public String get_new_image_path(final String dir) throws Exception {
        /*
        URL url = new URL("http://" + Config.IMAGE_SERVER + "/" + dir + "/image-count");
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        conn.setRequestMethod("GET");
        conn.connect();

        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
        StringBuffer sb = new StringBuffer();
        String responseData;
        while ((responseData = br.readLine()) != null) {
            sb.append(responseData); //StringBuffer에 응답받은 데이터 순차적으로 저장 실시
        }

        return sb.toString();
         */
        URI uri = new URI("http://" + IMAGE_SERVER + "/" + dir + "/image-count");
        RestTemplate rt = new RestTemplate();
        ResponseEntity<String> response = rt.getForEntity(uri, String.class);

        return response.getBody();
    }

    public void save_image(final String full_path, final Object image) throws Exception {
        /*
        URL url = new URL("http://" + IMAGE_SERVER + "/" + full_path);
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();

        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        OutputStream os = conn.getOutputStream();
        os.write(convertObjectToBytes((image)));
        os.flush();

        conn.connect();
         */
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        RestTemplate rt = new RestTemplate();
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("image", convertObjectToBytes(image));

        HttpEntity<String> entity = new HttpEntity<String>(jsonObject.toString(), headers);

        ResponseEntity<Void> response = rt.postForEntity(
                "http://" + IMAGE_SERVER + "/" + full_path,
                entity,
                Void.class
        );
    }

    // object to byte[]
    private static byte[] convertObjectToBytes(final Object obj) throws IOException {
        ByteArrayOutputStream boas = new ByteArrayOutputStream();
        try (ObjectOutputStream ois = new ObjectOutputStream(boas)) {
            ois.writeObject(obj);
            return boas.toByteArray();
        }
    }
}