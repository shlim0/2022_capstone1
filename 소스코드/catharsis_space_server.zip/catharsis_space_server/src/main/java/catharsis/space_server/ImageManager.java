package catharsis.space_server;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Paths;

public class ImageManager {
    public String get_new_image_path(final String dir) throws Exception {
        URL url = new URL("http://" + Config.IMAGE_SERVER + "/" + dir + "/image-count");
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        conn.setRequestMethod("GET");
        conn.connect();

        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
        StringBuffer sb = new StringBuffer();
        String responseData;
        while ((responseData = br.readLine()) != null) {
            sb.append(responseData); //StringBuffer에 응답받은 데이터 순차적으로 저장 실시
        }

        return sb.toString();
    }

    public void save_image(final String full_path, final Object image) throws Exception {
        URL url = new URL("http://" + Config.IMAGE_SERVER + "/" + full_path);
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();

        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        OutputStream os = conn.getOutputStream();
        os.write(convertObjectToBytes((image)));
        os.flush();

        conn.connect();
    }

    // object to byte[]
    private static byte[] convertObjectToBytes(final Object obj) throws IOException {
        ByteArrayOutputStream boas = new ByteArrayOutputStream();
        try (ObjectOutputStream ois = new ObjectOutputStream(boas)) {
            ois.writeObject(obj);
            return boas.toByteArray();
        }
    }
}